import React, { createContext } from 'react';
console.log("MyContext file is loading"); // Debugging
 
export const MyContext = React.createContext();